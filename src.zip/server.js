var express = require('express');
var http = require('http');
var path = require('path');
var app = express();
var mysql      = require('mysql');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
 
var connection = mysql.createConnection({
  host     : 'db4free.net',
    user     : 'srnet1234',
    password : 'srnet1234',
    database : 'srnet',
});
connection.connect(function(err){
    if(!err) {
        console.log("Database is connected ... \n\n");  
        var sql="CREATE TABLE ITEM_MASTER(ITEM_ID int NOT NULL AUTO_INCREMENT,ITEM_NAME varchar(5000),PRIMARY KEY (ITEM_ID))";
        connection.query(sql,callback);
        sql="CREATE TABLE USER_LOGIN(USER_ID int NOT NULL AUTO_INCREMENT,USER_NAME varchar(500),USER_PWD varchar(500),PRIMARY KEY(USER_ID))";
        connection.query(sql,callback);
    }else {
        console.log("Error connecting database ... \n\n");  
    }
 });
 var callback=function(err){
     if(!err){
               console.info("Created successfully...");
      }else{
               console.info("Error created of table"+err);
      }
 }
// all environments
app.set('port',process.env.PORT ||80);
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: false
}));
app.use(cookieParser());
app.set('view engine', 'html');
app.use(express.static(path.join(__dirname, 'src')));
app.use('/node_modules/',express.static(path.join(__dirname,'node_modules')));
app.get('/', function( req, res) {
	res.render("app/index");
});
app.post('/userverify',function(req,res){
    console.info("Request{}"+req);
    res.send("Hello")
})
http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});

