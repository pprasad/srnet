import { Routes, RouterModule } from '@angular/router';
import {LoginComponent} from './login/login.component';

const app_routes:Routes=[
    {path:'',pathMatch:'full',redirectTo:'/login'},
    {path:'login',component:LoginComponent,data:{showMenu:true}}
]
export const app_routing = {
  routes: RouterModule.forRoot(app_routes),
  components:[LoginComponent]
};