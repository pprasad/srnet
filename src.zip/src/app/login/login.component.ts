import {Component,OnInit} from "@angular/core";
import { Validators, FormGroup, FormArray, FormBuilder } from '@angular/forms';
import {MenuBarService} from '../services/service.menubar';
import {UserLogin} from '../dao/dao.userlogin';
import {RestfullService} from '../services/service.restfull';
@Component({
   moduleId: module.id,
  "templateUrl":'login.component.html',
   providers:[RestfullService]
})

export class LoginComponent implements OnInit{
    menuBar:MenuBarService; 
    public loginForm: FormGroup; 
    constructor(private menuBarService:MenuBarService,private _fb: FormBuilder,private service:RestfullService){
      this.menuBar=menuBarService;
    }
     ngOnInit() { 
        this.loginForm=this._fb.group({
            userName:['',Validators.required]
        })
     }

     public login(model:UserLogin){
       console.info(model);
       this.service.getUserLogin(model);//.then(res=>{console.info("response{}"+res);},error=>console.log(error));
       this.menuBar.routeIsChanging(true);
     }
}