"use strict";
var router_1 = require('@angular/router');
var login_component_1 = require('./login/login.component');
var app_routes = [
    { path: '', pathMatch: 'full', redirectTo: '/login' },
    { path: 'login', component: login_component_1.LoginComponent, data: { showMenu: true } }
];
exports.app_routing = {
    routes: router_1.RouterModule.forRoot(app_routes),
    components: [login_component_1.LoginComponent]
};
//# sourceMappingURL=app.routers.js.map